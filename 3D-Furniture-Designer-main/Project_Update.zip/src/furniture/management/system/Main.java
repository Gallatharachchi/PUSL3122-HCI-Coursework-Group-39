package furniture.management.system;

public class Main {

    public static void main(String[] args) {

       StartUp start = new StartUp();
       start.setVisible(true);
    }
}
